/* Сгенерировано из data.json — демо-данные и резервная копия. */
window.RESHOP_SEED = {
  "version": 1,
  "updatedAt": "2026-10-30T00:00:00.000Z",
  "settings": {
    "name": "reshop",
    "tagline": "Магазин предметов Dota 2",
    "telegram": "https://t.me/reshot",
    "currency": "₽",
    "hero": {
      "eyebrow": "Dota 2 · магазин предметов",
      "title": "Предметы, которые\n*решают* игру",
      "text": "Арканы, имморталы и редкие сеты — без посредников. Проверяю каждый предмет вручную и передаю через Steam-трейд или подарком.",
      "note": "2 400+ сделок · выдача 5–15 минут · гарантия",
      "facts": [
        {
          "value": "2 400+",
          "label": "сделок закрыто"
        },
        {
          "value": "5–15 мин",
          "label": "средняя выдача"
        },
        {
          "value": "4.9 / 5",
          "label": "рейтинг покупателей"
        }
      ]
    },
    "catalog": {
      "eyebrow": "Каталог",
      "title": "В наличии",
      "note": "Все предметы проверены вручную и готовы к передаче."
    },
    "footerNote": "reshop — независимый магазин предметов Dota 2. Не связан с Valve Corporation."
  },
  "about": {
    "eyebrow": "Обо мне",
    "title": "Привет, я *reshot*",
    "lead": "Продаю предметы Dota 2 с 2019 года. Без накруток, ботов и «серых» схем — только честный обмен и живая связь.",
    "paragraphs": [
      "Начал с пары аркан для друзей, а сегодня reshop — это небольшая мастерская, где каждый предмет проверен вручную. Я сам собираю инвентарь, сам общаюсь с покупателями и сам отвечаю, если что-то пошло не так.",
      "Работаю по предоплате или через гаранта — как удобнее вам. Все предметы оригинальные, получены с официального рынка Steam или из сундуков. После сделки остаюсь на связи: помогу с выбором стиля и подскажу по комбинациям."
    ],
    "name": "reshot",
    "role": "Владелец reshop · в Dota 2 с 2014",
    "avatar": "",
    "stats": [
      {
        "value": "2 400+",
        "label": "сделок"
      },
      {
        "value": "6 лет",
        "label": "на рынке"
      },
      {
        "value": "4.9",
        "label": "средний рейтинг"
      }
    ],
    "steps": [
      {
        "title": "Выбираете предмет",
        "text": "В каталоге или напишите мне в Telegram — подскажу, что есть в наличии и чем отличаются стили."
      },
      {
        "title": "Согласуем детали",
        "text": "Проверяем цену и способ передачи. Отвечаю в течение часа, обычно — гораздо быстрее."
      },
      {
        "title": "Получаете предмет",
        "text": "Передаю через Steam-трейд или подарком. Обычно это занимает 5–15 минут после оплаты."
      }
    ],
    "faq": [
      {
        "q": "Это безопасно?",
        "a": "Да. Передача идёт через официальный Steam-трейд или подарком. Я никогда не запрашиваю пароль и не прошу заходить на сторонние сайты."
      },
      {
        "q": "Как оплатить?",
        "a": "Переводом на карту или через СБП. Для крупных сделок — через гаранта, если так спокойнее."
      },
      {
        "q": "Почему цены ниже Steam Market?",
        "a": "Я работаю без комиссии торговой площадки и без посредников, поэтому могу держать цены ниже рынка."
      },
      {
        "q": "Что если предмет не подошёл?",
        "a": "Напишите в Telegram в течение суток. Если предмет ещё не передан — подберём замену или вернём деньги."
      },
      {
        "q": "Сколько ждать после оплаты?",
        "a": "Обычно 5–15 минут. В пиковые часы — до часа, но я всегда предупреждаю заранее."
      }
    ],
    "ctaTitle": "Готов сделать заказ?",
    "ctaText": "Напишите в Telegram. Если захотели что-то приобрести - сразу отвечу."
  },
  "items": [
    {
      "id": "demon-eater",
      "name": "Demon Eater",
      "hero": "Shadow Fiend",
      "slot": "Голова",
      "rarity": "arcana",
      "price": 2990,
      "oldPrice": 3490,
      "image": "assets/items/demon-eater.webp",
      "status": "in_stock",
      "hit": true,
      "description": "Аркана Shadow Fiend с тремя стилями и кастомными эффектами способностей. Полный набор: модель героя, иконки и звуки.",
      "telegram": "",
      "stock": 3
    },
    {
      "id": "magus-cypher",
      "name": "The Magus Cypher",
      "hero": "Rubick",
      "slot": "Набор",
      "rarity": "arcana",
      "price": 3290,
      "oldPrice": 0,
      "image": "assets/items/magus-cypher.webp",
      "status": "in_stock",
      "hit": false,
      "description": "Аркана Rubick: новый облик, эффекты заклинаний и альтернативные иконки. Один из самых заметных сетов в игре.",
      "telegram": "",
      "stock": 2
    },
    {
      "id": "voth-domosh",
      "name": "Blades of Voth Domosh",
      "hero": "Legion Commander",
      "slot": "Оружие",
      "rarity": "arcana",
      "price": 3690,
      "oldPrice": 4190,
      "image": "assets/items/voth-domosh.webp",
      "status": "in_stock",
      "hit": true,
      "description": "Аркана Legion Commander с двумя клинками, уникальными анимациями атаки и эффектами дуэли.",
      "telegram": "",
      "stock": 2
    },
    {
      "id": "fractal-horns",
      "name": "Fractal Horns of Inner Abysm",
      "hero": "Terrorblade",
      "slot": "Голова",
      "rarity": "arcana",
      "price": 3990,
      "oldPrice": 0,
      "image": "assets/items/fractal-horns.webp",
      "status": "in_stock",
      "hit": false,
      "description": "Аркана Terrorblade: рога, крылья и переработанные эффекты метаморфозы.",
      "telegram": "",
      "stock": 1
    },
    {
      "id": "feast-abscession",
      "name": "Feast of Abscession",
      "hero": "Pudge",
      "slot": "Оружие",
      "rarity": "arcana",
      "price": 2590,
      "oldPrice": 0,
      "image": "assets/items/feast-abscession.webp",
      "status": "in_stock",
      "hit": false,
      "description": "Аркана Pudge: крюк, разделочный стол и мрачные эффекты мясника.",
      "telegram": "",
      "stock": 4
    },
    {
      "id": "frost-avalanche",
      "name": "Frost Avalanche",
      "hero": "Crystal Maiden",
      "slot": "Набор",
      "rarity": "arcana",
      "price": 2190,
      "oldPrice": 2590,
      "image": "assets/items/frost-avalanche.webp",
      "status": "in_stock",
      "hit": true,
      "description": "Аркана Crystal Maiden: ледяная шаль, волчонок и зимние эффекты способностей.",
      "telegram": "",
      "stock": 3
    },
    {
      "id": "bladeform-legacy",
      "name": "Bladeform Legacy",
      "hero": "Juggernaut",
      "slot": "Голова",
      "rarity": "arcana",
      "price": 2890,
      "oldPrice": 0,
      "image": "assets/items/bladeform-legacy.webp",
      "status": "in_stock",
      "hit": false,
      "description": "Аркана Juggernaut: маска, клинок и кастомные эффекты Omnislash.",
      "telegram": "",
      "stock": 2
    },
    {
      "id": "great-sage",
      "name": "Great Sage's Reckoning",
      "hero": "Monkey King",
      "slot": "Набор",
      "rarity": "arcana",
      "price": 2790,
      "oldPrice": 0,
      "image": "assets/items/great-sage.webp",
      "status": "in_stock",
      "hit": false,
      "description": "Аркана Monkey King: посох, трансформация и полный набор эффектов.",
      "telegram": "",
      "stock": 1
    },
    {
      "id": "manifold-paradox",
      "name": "Manifold Paradox",
      "hero": "Phantom Assassin",
      "slot": "Оружие",
      "rarity": "arcana",
      "price": 2690,
      "oldPrice": 3190,
      "image": "assets/items/manifold-paradox.webp",
      "status": "in_stock",
      "hit": false,
      "description": "Аркана Phantom Assassin с двумя стилями клинков и уникальными эффектами.",
      "telegram": "",
      "stock": 2
    },
    {
      "id": "tempest-helm",
      "name": "Tempest Helm of the Thundergod",
      "hero": "Zeus",
      "slot": "Голова",
      "rarity": "arcana",
      "price": 2790,
      "oldPrice": 0,
      "image": "assets/items/tempest-helm.webp",
      "status": "in_stock",
      "hit": false,
      "description": "Аркана Zeus: шлем, молнии и переработанные эффекты способностей.",
      "telegram": "",
      "stock": 1
    },
    {
      "id": "peregrine",
      "name": "Peregrine Flight",
      "hero": "Windranger",
      "slot": "Оружие",
      "rarity": "immortal",
      "price": 690,
      "oldPrice": 0,
      "image": "assets/items/peregrine.webp",
      "status": "in_stock",
      "hit": false,
      "description": "Иммортал для Windranger: лук с эффектами Powershot и новыми звуками.",
      "telegram": "",
      "stock": 6
    },
    {
      "id": "concord-dominion",
      "name": "Concord Dominion",
      "hero": "Phantom Lancer",
      "slot": "Плечи",
      "rarity": "immortal",
      "price": 1190,
      "oldPrice": 0,
      "image": "assets/items/concord-dominion.webp",
      "status": "reserved",
      "hit": false,
      "description": "Иммортал для Phantom Lancer: наплечники с эффектами Phantom Rush.",
      "telegram": "",
      "stock": 1
    },
    {
      "id": "phantom-concord",
      "name": "Phantom Concord",
      "hero": "Phantom Lancer",
      "slot": "Оружие",
      "rarity": "immortal",
      "price": 590,
      "oldPrice": 0,
      "image": "assets/items/phantom-concord.webp",
      "status": "in_stock",
      "hit": false,
      "description": "Иммортал для Phantom Lancer: копьё с эффектами Spirit Lance.",
      "telegram": "",
      "stock": 4
    },
    {
      "id": "transversant-soul",
      "name": "Transversant Soul",
      "hero": "Spectre",
      "slot": "Плечи",
      "rarity": "immortal",
      "price": 890,
      "oldPrice": 0,
      "image": "assets/items/transversant-soul.webp",
      "status": "in_stock",
      "hit": false,
      "description": "Иммортал для Spectre: наплечники с эффектами Spectral Dagger.",
      "telegram": "",
      "stock": 2
    },
    {
      "id": "abscesserator",
      "name": "The Abscesserator",
      "hero": "Pudge",
      "slot": "Оружие",
      "rarity": "immortal",
      "price": 1090,
      "oldPrice": 0,
      "image": "assets/items/abscesserator.webp",
      "status": "sold",
      "hit": false,
      "description": "Иммортал для Pudge: крюк с кровавыми эффектами и звуками.",
      "telegram": "",
      "stock": 0
    }
  ]
};
